# Capítulo 2: Funciones Pequeñas (Versión 1.0.0)

Las funciones deben hacer una sola cosa, y hacerla bien.
