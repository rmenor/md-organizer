# Capítulo 1: Nombres con Significado (Versión 1.0.0)

> Fecha de esta edición: **2024-01-15** | Código: **BK-CLEAN-CODE**

El nombre de una variable, función o clase debe responder a las grandes preguntas: **por qué existe**, **qué hace** y **cómo se usa**.

```javascript
const VERSION = "1.0.0";
const RELEASE_DATE = "2024-01-15";
console.log("Cargando libro:", "BK-CLEAN-CODE", VERSION);
```
