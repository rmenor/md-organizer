# Capítulo 1: Nombres con Significado (Versión 0.9.0)

> Fecha de esta edición: **2023-10-01** | Código: **BK-CLEAN-CODE**

El nombre de una variable, función o clase debe responder a las grandes preguntas: **por qué existe**, **qué hace** y **cómo se usa**.

```javascript
const VERSION = "0.9.0";
const RELEASE_DATE = "2023-10-01";
console.log("Cargando libro:", "BK-CLEAN-CODE", VERSION);
```
