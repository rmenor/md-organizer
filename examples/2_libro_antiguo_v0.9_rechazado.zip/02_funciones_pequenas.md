# Capítulo 2: Funciones Pequeñas (Versión 0.9.0)

Las funciones deben hacer una sola cosa, y hacerla bien.
