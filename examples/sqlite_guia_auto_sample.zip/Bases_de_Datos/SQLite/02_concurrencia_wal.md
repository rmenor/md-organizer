# Concurrencia y Modo WAL

El modo Write-Ahead Logging (WAL) mejora significativamente el rendimiento de concurrencia en SQLite.

Permite que múltiples lectores operen de forma simultánea mientras un único escritor realiza modificaciones.

```sql
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
```
