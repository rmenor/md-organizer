---
title: Introducción a SQLite y Sistemas Embebidos
author: Richard Hipp
---

# Introducción a SQLite y Sistemas Embebidos

SQLite es una biblioteca en lenguaje C que implementa un motor de base de datos SQL pequeño, rápido, autónomo, de alta confiabilidad y con todas las funciones.

## Características Principales

- **Serverless**: No requiere un proceso servidor independiente.
- **Zero Configuration**: No hay pasos de instalación o administración.
- **Single File**: Todo el contenido se almacena en un único archivo en disco.
