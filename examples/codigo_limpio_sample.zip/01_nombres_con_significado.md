# Capítulo 1: Nombres con Significado

El nombre de una variable, función o clase debe responder a las grandes preguntas: **por qué existe**, **qué hace** y **cómo se usa**. Si un nombre requiere un comentario, entonces no revela su intención.

## Reglas de Oro

1. **Usa nombres que revelen la intención**:
```javascript
// ❌ Confuso
const d = 86400; // tiempo en segundos

// ✅ Claro y auto-explicativo
const SECONDS_PER_DAY = 86400;
```

2. **Evita la desinformación**:
No uses nombres que induzcan a error sobre la estructura subyacente. Por ejemplo, no llames `userList` a un conjunto que no sea una lista.

> "El código se lee mucho más a menudo de lo que se escribe." - *Guido van Rossum*
