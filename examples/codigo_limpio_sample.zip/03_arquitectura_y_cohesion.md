# Capítulo 3: Arquitectura y Cohesión

Un sistema de software de calidad está compuesto por módulos altamente cohesivos y débilmente acoplados.

## Separación de Intereses

Mantener la lógica de negocio separada de la capa de transporte (HTTP) y persistencia (Base de Datos) garantiza que el sistema pueda evolucionar sin fricción.

- **Dominio**: Reglas de negocio puras.
- **Casos de Uso**: Coordinación de operaciones.
- **Adaptadores**: Base de datos SQLite, API REST, UI.

```mermaid
graph TD
  UI --> CasosDeUso
  CasosDeUso --> Entidades
  CasosDeUso --> RepositorioSQLite
```
