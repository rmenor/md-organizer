# Capítulo 2: Funciones Pequeñas y Enfocadas

La primera regla de las funciones es que **deben ser pequeñas**. La segunda regla es que **deben ser aún más pequeñas**.

## Principio de Responsabilidad Única (SRP)

Las funciones solo deben hacer una cosa, deben hacerla bien y deben hacerla únicamente.

| Métrica | Recomendación |
| :--- | :--- |
| Longitud de líneas | < 20 líneas |
| Número de argumentos | 0 a 2 argumentos (idealmente mónadas o díadas) |
| Efectos secundarios | Ninguno |

### Ejemplo:

```javascript
function calculateFinalPrice(cart, discountPolicy) {
  const subtotal = calculateSubtotal(cart.items);
  const discount = discountPolicy.apply(subtotal);
  const tax = calculateTax(subtotal - discount);
  return subtotal - discount + tax;
}
```
